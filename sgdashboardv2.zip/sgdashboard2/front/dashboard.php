<?php

require '../../../inc/includes.php';

Session::checkLoginUser();

if (isset($_POST['save_iframe']) && Session::haveRight('config', UPDATE)) {
   $iframe = $_POST['iframe_code'] ?? '';
   Config::setConfigurationValues('plugin:sgdashboard', ['iframe_code' => $iframe]);
   Html::back();
}

PluginSgdashboardDashboard::display();
