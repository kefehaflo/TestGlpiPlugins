<?php

if (!defined('GLPI_ROOT')) {
   die('Direct access not allowed');
}

function plugin_sgdashboard_install() {
   return true;
}

function plugin_sgdashboard_uninstall() {
   Config::deleteConfigurationValues('plugin:sgdashboard');
   return true;
}
