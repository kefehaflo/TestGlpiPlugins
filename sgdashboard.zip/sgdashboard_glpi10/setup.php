<?php

if (!defined('GLPI_ROOT')) {
   define('GLPI_ROOT', '../../..');
}

// Versión del plugin
define('PLUGIN_SGDASHBOARD_VERSION', '1.0.0');

// Versión mínima y máxima de GLPI soportadas
define('PLUGIN_SGDASHBOARD_MIN_GLPI_VERSION', '10.0.0');
define('PLUGIN_SGDASHBOARD_MAX_GLPI_VERSION', '10.0.99');

/**
 * Inicialización del plugin
 */
function plugin_init_sgdashboard() {
   global $PLUGIN_HOOKS;

   // Compatible con CSRF
   $PLUGIN_HOOKS['csrf_compliant']['sgdashboard'] = true;

   // Añadir entrada en el menú "Plugins"
   // Se mostrará como item central "Dashboard SG"
   $PLUGIN_HOOKS['menu_toadd']['sgdashboard'] = [
      'plugins' => 'PluginSgdashboardDashboard'
   ];
}

/**
 * Información del plugin (se muestra en Configuración > Plugins)
 */
function plugin_version_sgdashboard() {
   return [
      'name'         => 'SG Dashboard embebido',
      'version'      => PLUGIN_SGDASHBOARD_VERSION,
      'author'       => 'Kevin / Manantial + ChatGPT',
      'license'      => 'MIT',
      'homepage'     => '',
      'requirements' => [
         'glpi' => [
            'min' => PLUGIN_SGDASHBOARD_MIN_GLPI_VERSION,
            'max' => PLUGIN_SGDASHBOARD_MAX_GLPI_VERSION,
         ]
      ]
   ];
}

/**
 * Verificación de prerequisitos (versión de GLPI)
 */
function plugin_sgdashboard_check_prerequisites() {
   if (version_compare(GLPI_VERSION, PLUGIN_SGDASHBOARD_MIN_GLPI_VERSION, 'lt')
       || version_compare(GLPI_VERSION, PLUGIN_SGDASHBOARD_MAX_GLPI_VERSION, 'ge')) {

      echo 'Este plugin requiere GLPI entre '
         . PLUGIN_SGDASHBOARD_MIN_GLPI_VERSION
         . ' y '
         . PLUGIN_SGDASHBOARD_MAX_GLPI_VERSION;

      return false;
   }
   return true;
}

/**
 * Comprobación de configuración (por ahora siempre OK)
 */
function plugin_sgdashboard_check_config($verbose = false) {
   if ($verbose) {
      // Mensaje si quisieras indicar algo de config
      // _e('Plugin instalado / sin configuración adicional', 'sgdashboard');
   }
   return true;
}
