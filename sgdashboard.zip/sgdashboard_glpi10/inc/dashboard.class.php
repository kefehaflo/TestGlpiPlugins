<?php

if (!defined('GLPI_ROOT')) {
   die('Direct access not allowed');
}

class PluginSgdashboardDashboard extends CommonGLPI {

   /**
    * Nombre visible del tipo
    */
   public static function getTypeName($nb = 0) {
      return __('Dashboard SG', 'sgdashboard');
   }

   /**
    * Nombre que se muestra en el menú
    */
   public static function getMenuName($nb = 0) {
      return self::getTypeName($nb);
   }

   /**
    * Contenido del menú "Plugins"
    */
   public static function getMenuContent() {
      $title = self::getMenuName(1);
      $page  = self::getFormURL(false);

      return [
         'title'   => $title,
         'page'    => $page,
         'options' => []
      ];
   }

   /**
    * URL del formulario principal del plugin
    */
   public static function getFormURL($full = true) {
      global $CFG_GLPI;

      $link = '/plugins/sgdashboard/front/dashboard.php';

      if ($full) {
         return $CFG_GLPI['root_doc'] . $link;
      }
      return $link;
   }

   /**
    * Render de la página principal
    */
   public static function display() {

      // Leer configuración almacenada (código iframe)
      $config = Config::getConfigurationValues('plugin:sgdashboard');
      $iframe = isset($config['iframe_code']) ? $config['iframe_code'] : '';

      Html::header(
         self::getTypeName(1),
         '',
         'plugins',
         'sgdashboard',
         'dashboard'
      );

      echo "<div class='center' style='margin:15px;'>";
      echo "<h2>" . self::getTypeName(1) . "</h2>";

      // Mostrar iframe si existe
      if (!empty($iframe)) {
         echo "<div style='margin-top:15px;'>";
         echo $iframe;
         echo "</div>";
      } else {
         echo "<p>" . __('Aún no se ha configurado el iframe del dashboard.', 'sgdashboard') . "</p>";
      }

      // Formulario para configurar el iframe (solo usuarios con derecho de config)
      if (Session::haveRight('config', UPDATE)) {

         $textarea_value = Html::entities_deep($iframe);

         echo "<form method='post' action='' style='margin-top:20px;'>";
         echo "<table class='tab_cadre_fixe'>";
         echo "<tr><th>" . __('Configurar iframe del dashboard', 'sgdashboard') . "</th></tr>";
         echo "<tr class='tab_bg_1'><td class='center'>";
         echo "<textarea name='iframe_code' cols='120' rows='10'>".$textarea_value."</textarea>";
         echo "</td></tr>";
         echo "<tr class='tab_bg_2'><td class='center'>";
         echo "<input type='submit' name='save_iframe' class='submit' value='" . _sx('button','Save') . "'>";
         echo "</td></tr>";
         echo "</table>";
         echo "</form>";
      }

      echo "</div>";

      Html::footer();
   }
}
