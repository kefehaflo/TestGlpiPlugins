<?php

use Glpi\Plugin\Hooks;

define('PLUGIN_SGDASHBOARD_VERSION', '1.0.0');
define('PLUGIN_SGDASHBOARD_MIN_GLPI_VERSION', '10.0.0');
define('PLUGIN_SGDASHBOARD_MAX_GLPI_VERSION', '10.0.99');

/**
 * Inicialización del plugin
 */
function plugin_init_sgdashboard() {
   global $PLUGIN_HOOKS;

   // El plugin es compatible con el sistema CSRF
   $PLUGIN_HOOKS['csrf_compliant']['sgdashboard'] = true;

   // Añadir entrada en el menú "Plugins"
   $PLUGIN_HOOKS[Hooks::MENU_TOADD]['sgdashboard'] = [
      'plugins' => PluginSgdashboardDashboard::class
   ];
}

/**
 * Información del plugin (se muestra en Configuración > Plugins)
 */
function plugin_version_sgdashboard() {
   return [
      'name'         => 'SG Dashboard embebido',
      'version'      => PLUGIN_SGDASHBOARD_VERSION,
      'author'       => 'Kevin / Manantial + ChatGPT',
      'license'      => 'MIT',
      'homepage'     => '',
      'requirements' => [
         'glpi' => [
            'min' => PLUGIN_SGDASHBOARD_MIN_GLPI_VERSION,
            'max' => PLUGIN_SGDASHBOARD_MAX_GLPI_VERSION,
         ]
      ]
   ];
}

/**
 * Comprobación de la configuración
 */
function plugin_sgdashboard_check_config($verbose = false) {
   return true;
}
