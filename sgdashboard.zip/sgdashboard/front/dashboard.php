<?php

require '../../../inc/includes.php';

Session::checkLoginUser();

// Guardar iframe si se envía el formulario
if (isset($_POST['save_iframe']) && Session::haveRight('config', UPDATE)) {
   $iframe = isset($_POST['iframe_code']) ? $_POST['iframe_code'] : '';

   // Guardar configuración
   Config::setConfigurationValues('plugin:sgdashboard', [
      'iframe_code' => $iframe
   ]);

   Html::back();
}

// Mostrar página principal
PluginSgdashboardDashboard::display();
