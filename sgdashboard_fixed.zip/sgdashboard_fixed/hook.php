<?php

if (!defined('GLPI_ROOT')) {
   die('Direct access not allowed');
}

/**
 * Instalación del plugin
 */
function plugin_sgdashboard_install() {
   // No se crean tablas por ahora
   return true;
}

/**
 * Desinstalación del plugin
 */
function plugin_sgdashboard_uninstall() {
   // Eliminar valores de configuración
   Config::deleteConfigurationValues('plugin:sgdashboard');
   return true;
}
