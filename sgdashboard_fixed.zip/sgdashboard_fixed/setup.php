<?php

if (!defined('GLPI_ROOT')) {
   define('GLPI_ROOT', '../../..');
}

/**
 * Inicialización del plugin
 */
function plugin_init_sgdashboard() {
   global $PLUGIN_HOOKS;

   // El plugin es compatible con CSRF
   $PLUGIN_HOOKS['csrf_compliant']['sgdashboard'] = true;

   // Añadir entrada en el menú "Plugins"
   // Se mostrará como un ítem en el menú central de Plugins
   $PLUGIN_HOOKS['menu_toadd']['sgdashboard'] = [
      'plugins' => 'PluginSgdashboardDashboard'
   ];
}

/**
 * Información básica del plugin
 */
function plugin_version_sgdashboard() {
   return [
      'name'           => 'SG Dashboard embebido',
      'version'        => '1.0.0',
      'author'         => 'Kevin / Manantial + ChatGPT',
      'license'        => 'MIT',
      'homepage'       => '',
      'minGlpiVersion' => '10.0.0',
      'maxGlpiVersion' => '10.0.99'
   ];
}

/**
 * Verificación de prerequisitos
 */
function plugin_sgdashboard_check_prerequisites() {

   if (version_compare(GLPI_VERSION, '10.0.0', 'lt')) {
      echo 'Este plugin requiere GLPI >= 10.0.0';
      return false;
   }
   return true;
}

/**
 * Comprobación de configuración
 */
function plugin_sgdashboard_check_config($verbose = false) {
   return true;
}
